#include "Foo.h"

class Foo::impl
{

};